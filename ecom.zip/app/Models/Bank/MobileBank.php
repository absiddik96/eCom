<?php

namespace App\Models\Bank;

use Illuminate\Database\Eloquent\Model;

class MobileBank extends Model
{
    protected $fillable = ['name'];
}
