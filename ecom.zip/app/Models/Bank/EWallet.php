<?php

namespace App\Models\Bank;

use Illuminate\Database\Eloquent\Model;

class EWallet extends Model
{
    protected $fillable = ['name'];
}
