<?php

namespace App\Models\Admin\ProductAccessories\Type;

use Illuminate\Database\Eloquent\Model;

class Type extends Model
{
    function getTypeAttribute($value='')
    {
    	return strtoupper($value);
    }

    public function categories()
    {
    	return $this->hasMany('App\Models\Admin\ProductAccessories\Category\Category');
    }
}
